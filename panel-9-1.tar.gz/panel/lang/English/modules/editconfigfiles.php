<?php

define('OGP_LANG_configuration_files', "Configuration Files");
define('OGP_LANG_editing_file', "Editing File");
define('OGP_LANG_no_server_specfied', "No Server ID specified - can't list any configuration files.");
define('OGP_LANG_no_home', "You don't have access to the given Server ID.");
define('OGP_LANG_no_configs_for_game', "This has no configuration files defined.");
define('OGP_LANG_name', "Name");
define('OGP_LANG_no_description', "No Description");
define('OGP_LANG_description', "Description");
define('OGP_LANG_invalid_file', "The specified file may not be edited.");
define('OGP_LANG_wrote_changes', "Successfully saved the file.");
define('OGP_LANG_failed_write', "Failed to save the file.");
define('OGP_LANG_failed_read', "Failed to read the file.");
define('OGP_LANG_save', "Save");
define('OGP_LANG_go_back', "Go Back");
define('OGP_LANG_new_file', "New File");