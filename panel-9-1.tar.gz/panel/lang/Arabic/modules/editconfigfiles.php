<?php

define('OGP_LANG_configuration_files', "ملفات التكوين");
define('OGP_LANG_editing_file', "تعديل الملف");
define('OGP_LANG_no_server_specfied', "لا يوجد اي دي خادم محدد - لا يمكن سرد أية ملفات تكوين.");
define('OGP_LANG_no_home', "ليس لديك حق الوصول إلى معرف الخادم المعين.");
define('OGP_LANG_no_configs_for_game', "لم يتم تحديد ملفات التكوين هذه.");
define('OGP_LANG_name', "الاسم");
define('OGP_LANG_no_description', "بدون وصف");
define('OGP_LANG_description', "الوصف");
define('OGP_LANG_invalid_file', "قد لا يتم تحرير الملف المحدد.");
define('OGP_LANG_wrote_changes', "تم حفظ الملف بنجاح.");
define('OGP_LANG_failed_write', "أخفق حفظ الملف.");
define('OGP_LANG_failed_read', "أخفق قراءة الملف.");
define('OGP_LANG_save', "حفظ");
define('OGP_LANG_go_back', "رجوع");
define('OGP_LANG_new_file', "ملف جديد");