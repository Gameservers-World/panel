<?php

define('OGP_LANG_configuration_files', "קבצי הגדרות");
define('OGP_LANG_editing_file', "עריכת קבצים");
define('OGP_LANG_no_server_specfied', "לא צוין מזהה שרת - לא ניתן לרשום קבצי הגדרות.");
define('OGP_LANG_no_home', "אין לך גישה למזהה השרת הנתון.");
define('OGP_LANG_no_configs_for_game', "לא הוגדרו קבצי הגדרה");
define('OGP_LANG_name', "שם");
define('OGP_LANG_no_description', "אין תיאור");
define('OGP_LANG_description', "תיאור");
define('OGP_LANG_invalid_file', "יתכן שלא ניתן לערוך את הקובץ שצוין");
define('OGP_LANG_wrote_changes', "שמירת הקובץ הושלמה");
define('OGP_LANG_failed_write', "שמירת הקובץ נכשלה");
define('OGP_LANG_failed_read', "קריאת הקובץ נכשלה");
define('OGP_LANG_save', "שמירה");
define('OGP_LANG_go_back', "חזור אחורה");
define('OGP_LANG_new_file', "קובץ חדש");