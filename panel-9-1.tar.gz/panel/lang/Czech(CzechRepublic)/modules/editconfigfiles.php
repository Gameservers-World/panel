<?php

define('OGP_LANG_configuration_files', "Konfigurační soubory");
define('OGP_LANG_editing_file', "Úpravy souboru");
define('OGP_LANG_no_server_specfied', "Nebyl zadán žádný ID serveru - nelze uvést žádné konfigurační soubory.");
define('OGP_LANG_no_home', "Nemáte přístup k danému ID serveru.");
define('OGP_LANG_no_configs_for_game', "To nemá definované konfigurační soubory.");
define('OGP_LANG_name', "Název");
define('OGP_LANG_no_description', "Bez popisu");
define('OGP_LANG_description', "Popis");
define('OGP_LANG_invalid_file', "Zadaný soubor nemusí být upravován.");
define('OGP_LANG_wrote_changes', "Soubor byl úspěšně uložen.");
define('OGP_LANG_failed_write', "Soubor se nezdařil.");
define('OGP_LANG_failed_read', "Soubor se nepodařilo přečíst.");
define('OGP_LANG_save', "Uložit");
define('OGP_LANG_go_back', "Vraťte se zpět");
define('OGP_LANG_new_file', "Nový soubor");