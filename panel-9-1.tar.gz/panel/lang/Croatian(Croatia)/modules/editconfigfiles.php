<?php

define('OGP_LANG_configuration_files', "Konfiguracijske datoteke");
define('OGP_LANG_editing_file', "Uređivanje datoteke");
define('OGP_LANG_no_server_specfied', "Nije naveden nijedan ID servera - ne može popisati nikakve konfiguracijske datoteke.");
define('OGP_LANG_no_home', "Nemate pristup odredenom ID Serveru");
define('OGP_LANG_no_configs_for_game', "Ovdje nema konfiguracije definiranih datoteka .");
define('OGP_LANG_name', "Ime");
define('OGP_LANG_no_description', "Bez opisa");
define('OGP_LANG_description', "Opis");
define('OGP_LANG_invalid_file', "Navedena datoteka možda neće biti uređena.");
define('OGP_LANG_wrote_changes', "Datoteka je uspješno spremljena.");
define('OGP_LANG_failed_write', "Spremanje datoteke nije uspjelo.");
define('OGP_LANG_failed_read', "Čitanje datoteke nije uspjelo.");
define('OGP_LANG_save', "Spremiti");
define('OGP_LANG_go_back', "Natrag");
define('OGP_LANG_new_file', "Nova Datoteka");