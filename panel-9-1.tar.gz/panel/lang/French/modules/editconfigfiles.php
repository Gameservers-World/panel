<?php

define('OGP_LANG_configuration_files', "Fichiers de Configuration");
define('OGP_LANG_editing_file', "Edition du Fichier");
define('OGP_LANG_no_server_specfied', "Pas d'ID Serveur spécifié - impossible de lister les fichiers de configuration.");
define('OGP_LANG_no_home', "Vous n'avez pas accès à cet ID Serveur.");
define('OGP_LANG_no_configs_for_game', "Il n'y a pas des fichiers de configuration définis.");
define('OGP_LANG_name', "Nom");
define('OGP_LANG_no_description', "Pas de Description");
define('OGP_LANG_description', "Description");
define('OGP_LANG_invalid_file', "Le fichier spécifié ne peut pas être édité.");
define('OGP_LANG_wrote_changes', "Fichier enregistré avec succès.");
define('OGP_LANG_failed_write', "Echec lors de l'enregistrement du fichier.");
define('OGP_LANG_failed_read', "Echec lors de la lecture du fichier.");
define('OGP_LANG_save', "Enregistrer");
define('OGP_LANG_go_back', "Retour");
define('OGP_LANG_new_file', "Nouveau Fichier");