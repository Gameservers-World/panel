<?php

define('OGP_LANG_configuration_files', "Konfigurációs fájlok");
define('OGP_LANG_editing_file', "Fájl szerkesztése");
define('OGP_LANG_no_server_specfied', "Nincs megadva a szerver azonosító - nem listázhat semmilyen konfigurációs fájlt.");
define('OGP_LANG_no_home', "Nincs hozzáférésed az adott szerver azonosítóhoz.");
define('OGP_LANG_no_configs_for_game', "Ez nem rendelkezik konfigurációs fájlokkal.");
define('OGP_LANG_name', "Név");
define('OGP_LANG_no_description', "Nincs leírás");
define('OGP_LANG_description', "Leírás");
define('OGP_LANG_invalid_file', "A megadott fájl nem szerkeszthető.");
define('OGP_LANG_wrote_changes', "Sikeresen mentette a fájlt.");
define('OGP_LANG_failed_write', "Nem sikerült menteni a fájlt.");
define('OGP_LANG_failed_read', "Nem sikerült olvasni a fájlt.");
define('OGP_LANG_save', "Mentés");
define('OGP_LANG_go_back', "Menj vissza");
define('OGP_LANG_new_file', "Új fájl");