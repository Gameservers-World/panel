<?php

define('OGP_LANG_configuration_files', "Konfigurationsdateien");
define('OGP_LANG_editing_file', "Datei bearbeiten");
define('OGP_LANG_no_server_specfied', "Keine Server-ID angegeben - kann keine Konfigurationsdateien auflisten.");
define('OGP_LANG_no_home', "Sie haben keinen Zugriff auf die angegebene Server-ID.");
define('OGP_LANG_no_configs_for_game', "Es sind keine Konfigurationsdateien definiert.");
define('OGP_LANG_name', "Namen");
define('OGP_LANG_no_description', "Keine Beschreibung");
define('OGP_LANG_description', "Beschreibung");
define('OGP_LANG_invalid_file', "Die angegebene Datei wird möglicherweise nicht bearbeitet.");
define('OGP_LANG_wrote_changes', "Die Datei erfolgreich gespeichert.");
define('OGP_LANG_failed_write', "Die Datei konnte nicht gespeichert werden.");
define('OGP_LANG_failed_read', "Die Datei konnte nicht gelesen werden.");
define('OGP_LANG_save', "speichern");
define('OGP_LANG_go_back', "Geh zurück");
define('OGP_LANG_new_file', "Neue Datei");