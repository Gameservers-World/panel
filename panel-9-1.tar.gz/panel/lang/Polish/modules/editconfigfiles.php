<?php

define('OGP_LANG_configuration_files', "Pliki konfiguracyjne");
define('OGP_LANG_editing_file', "Edycja pliku");
define('OGP_LANG_no_server_specfied', "Nie określono identyfikatora serwera - nie można wyświetlić żadnych plików konfiguracyjnych.");
define('OGP_LANG_no_home', "Nie masz dostępu do serwera ID");
define('OGP_LANG_no_configs_for_game', "Nie zdefiniowano plików konfiguracyjnych.");
define('OGP_LANG_name', "Nazwa");
define('OGP_LANG_no_description', "Bez opisu");
define('OGP_LANG_description', "Opis");
define('OGP_LANG_invalid_file', "Plik nie może być edytowany.");
define('OGP_LANG_wrote_changes', "Pomyślnie zapisano.");
define('OGP_LANG_failed_write', "Błąd zapisywania pliku.");
define('OGP_LANG_failed_read', "Błąd odczytywania pliku.");
define('OGP_LANG_save', "Zapisz");
define('OGP_LANG_go_back', "Wróć");
define('OGP_LANG_new_file', "Nowy plik");