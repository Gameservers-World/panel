<?php

define('OGP_LANG_configuration_files', "Konfigurations filer");
define('OGP_LANG_editing_file', "Redigere fil");
define('OGP_LANG_no_server_specfied', "Ingen Server ID specificeret - Kan ikke visse nogen konfigurations filer.");
define('OGP_LANG_no_home', "Du har ikke adgang til det givne Server ID.");
define('OGP_LANG_no_configs_for_game', "Dette har ingen konfigurations filer defineret.");
define('OGP_LANG_name', "Navn");
define('OGP_LANG_no_description', "In Beskrivelse");
define('OGP_LANG_description', "Beskrivelse");
define('OGP_LANG_invalid_file', "Den angivne fil må ikke redigeres");
define('OGP_LANG_wrote_changes', "Gemt filen succesfuldt.");
define('OGP_LANG_failed_write', "Fejlede i at gemme filen.");
define('OGP_LANG_failed_read', "Fejlede i at læse filen.");
define('OGP_LANG_save', "Gem");
define('OGP_LANG_go_back', "Gå tilbage");
define('OGP_LANG_new_file', "Ny fil");