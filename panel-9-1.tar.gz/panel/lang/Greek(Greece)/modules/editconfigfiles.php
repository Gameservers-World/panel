<?php

define('OGP_LANG_configuration_files', "Αρχεία Διαμόρφωσης");
define('OGP_LANG_editing_file', "Επεξεργασία Αρχείου");
define('OGP_LANG_no_server_specfied', "Δεν έχει καθοριστεί ID διακομιστή - δεν γίνεται να απαριθμηστούν αρχεία διαμόρφωσης.");
define('OGP_LANG_no_home', "Δεν έχετε πρόσβαση στο ID διακομιστή που έχει δοθεί.");
define('OGP_LANG_no_configs_for_game', "Αυτό δεν έχει καθορισμένα αρχεία διαμόρφωσης.");
define('OGP_LANG_name', "Όνομα");
define('OGP_LANG_no_description', "Δεν υπάρχει περιγραφή.");
define('OGP_LANG_description', "Περιγραφή");
define('OGP_LANG_invalid_file', "Το καθορισμένο αρχείο ενδέχεται να μην είναι επεξεργασμένο.");
define('OGP_LANG_wrote_changes', "Το αρχείο αποθηκεύτηκε με επιτυχία.");
define('OGP_LANG_failed_write', "Το αρχείο απέτυχε να αποθηκευτεί.");
define('OGP_LANG_failed_read', "Το αρχείο απέτυχε να διαβαστεί.");
define('OGP_LANG_save', "Αποθηκεύστε");
define('OGP_LANG_go_back', "Πηγαίνετε Πίσω");
define('OGP_LANG_new_file', "Νέο Αρχείο");