<?php
###############################################
# Site configuration
###############################################
$db_host="localhost";
$db_user="localuser";
$db_pass="Pkloyn7yvpht!";
$db_name="panel";
$table_prefix="ogp_";
$db_type="mysql";
?>
